use city_sales;


CREATE TABLE Sales_Data(
    Business_ID varchar(50),
    Login_Date Varchar (50),
    Sales_Amount DECIMAL(10, 2),
    GST_Amount DECIMAL(10, 2),
    Payment_Mode VARCHAR(50),
    FOREIGN KEY (Business_ID) REFERENCES Business_info(Business_ID)
);

SET FOREIGN_KEY_CHECKS = 1;


drop table sales_data;

load data infile 
"E:/city_sales Project/MySQL/CSV File/Table 4.csv"
into table sales_data
fields terminated by ','
lines terminated by '\n'
ignore 1 rows;

select * from sales_data;

select count(*) from sales_data;