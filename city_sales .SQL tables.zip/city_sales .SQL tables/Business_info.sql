use city_sales;

CREATE TABLE Business_info (
    Business_ID VARCHAR (10) PRIMARY KEY,
    Business_Name VARCHAR(255) NOT NULL,
    Contact_Person VARCHAR(255),
    Address VARCHAR(255),
    PinCode VARCHAR(10),
    City VARCHAR(50),
    State VARCHAR(50)
);

drop table business_info;


load data infile 
"E:/city_sales Project/MySQL/CSV File/Table 1 Business_info.csv"
into table Business_info
fields terminated by ','
lines terminated by '\n'
ignore 1 rows;

select * FROM business_info;

select count(*) from Business_info; 

select * from business_info where business_Name regexp '^{10}' ;