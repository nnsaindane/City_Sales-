use city_sales;

CREATE TABLE MEETING_INFO (
    BUSINESS_ID varchar(50),
    Tellercalername VARCHAR(255),
    BDMname VARCHAR(255),
    Callingdate varchar(100),
    Meetingdate varchar(200),
    Meetingtime varchar(100),
    Meetingstatus VARCHAR(50),
    FOREIGN KEY (BUSINESS_ID) REFERENCES BUSINESS_INFO (BUSINESS_ID)
);
 
 DROP table MEETING_INFO;

SELECT * FROM MEETING_INFO;
 
load data infile 
"E:/city_sales Project/MySQL/CSV File/table 2 Meeting_data.csv"
into table MEETING_INFO
fields terminated by ','
lines terminated by '\n'
ignore 1 rows; 

select	count(*) from meeting_info;
