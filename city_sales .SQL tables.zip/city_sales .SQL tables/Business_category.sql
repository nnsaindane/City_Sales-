USE city_sales;

CREATE TABLE Business_Category (
    Business_ID varchar(10),
    Business_Sub_Category VARCHAR(255),
    Map VARCHAR(255),
    Product_Proposal VARCHAR(255),
    FOREIGN KEY (Business_ID) REFERENCES Business_info(Business_ID)
);

drop table business_Category;

load data infile
"E:/city_sales Project/MySQL/CSV File/Table 3 Business_Category .csv"
into table business_category
fields terminated by ','
lines terminated by '\n'
ignore 1 rows; 

select * from business_category;
